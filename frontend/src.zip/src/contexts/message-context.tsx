import React, { createContext, useContext, useState, useEffect, ReactNode, useCallback } from "react";
import { useAuth } from "./auth-context";
import { Message } from "../types";
import { sendMessage, getMessagesByProject } from "../utils/messages";

type MessageContextType = {
  messages: Message[];
  isLoading: boolean;
  error: string | null;
  fetchMessages: () => Promise<void>;
  sendMessage: (content: string, receiverId?: string) => Promise<void>;
};

const MessageContext = createContext<MessageContextType | null>(null);

export const useMessages = () => {
  const context = useContext(MessageContext);
  if (!context) throw new Error("useMessages must be used within MessageProvider");
  return context;
};

export const MessageProvider: React.FC<{ projectId: string; children: ReactNode }> = ({ projectId, children }) => {
  const { user } = useAuth();
  const [messages, setMessages] = useState<Message[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Fetch messages for this project
  const fetchMessages = useCallback(async () => {
    if (!user) return;

    setIsLoading(true);
    setError(null);
    try {
      const data = await getMessagesByProject(projectId);
      setMessages(Array.isArray(data) ? data : []);
    } catch (err: any) {
      setError(err.message || "Failed to fetch messages");
    } finally {
      setIsLoading(false);
    }
  }, [projectId, user]);

  // Send a new message
  const sendMessage = useCallback(
    async (projectId: string, content: string, receiverId?: string) => {
      if (!user) return;

      setIsLoading(true);
      setError(null);
      try {
        console.log('message info context before: ', projectId, content, receiverId);
        const newMessage = await sendMessage(projectId, content, receiverId);
        console.log('message info context: ', projectId, content, receiverId);
        setMessages((prev) => [...prev, newMessage]);
      } catch (err: any) {
        setError(err.message || "Failed to send message");
      } finally {
        setIsLoading(false);
      }
    },
    [projectId, user]
  );

  // Auto-fetch messages when projectId or user changes
  useEffect(() => {
    fetchMessages();
  }, [fetchMessages]); // fetchMessages is stable due to useCallback

  return (
    <MessageContext.Provider
      value={{
        messages,
        isLoading,
        error,
        fetchMessages,
        sendMessage,
      }}
    >
      {children}
    </MessageContext.Provider>
  );
};
